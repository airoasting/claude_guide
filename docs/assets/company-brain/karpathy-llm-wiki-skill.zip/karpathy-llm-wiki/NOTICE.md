# 출처와 수정 내역

이 폴더는 오픈소스 스킬 `karpathy-llm-wiki`를 Claude 데스크톱 앱에 업로드할 수 있게 다시 묶은 것입니다.

- 원본: https://github.com/Astro-Han/karpathy-llm-wiki (MIT License, 원문은 LICENSE 파일)
- 원본 방식: Andrej Karpathy가 공개한 LLM 위키 (https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)
- 재배포: AI ROASTING 가이드 (https://airoasting.github.io/claude_guide/company-brain-practice.html)

## 원본에서 바꾼 것 하나

`SKILL.md` 앞머리의 `description` 한 줄을 줄였습니다. Claude 데스크톱 앱의 사용자 지정 스킬은
description을 200자까지만 받는데, 원본은 247자라 그대로는 업로드되지 않습니다.
줄인 문장의 뜻은 원본과 같습니다. 본문 규칙은 한 글자도 고치지 않았습니다.

## 빠진 것

원본 저장소의 `README.md`, `examples/`, `tests/`, `assets/`는 넣지 않았습니다.
스킬이 도는 데 필요하지 않고, 업로드 용량만 늘리기 때문입니다. 원본 저장소에서 볼 수 있습니다.
